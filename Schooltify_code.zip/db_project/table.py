from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy() #連接資料庫
        
class ps(db.Model): #幼兒園
    __tablename__ = "preschool"
    num = db.Column(db.Integer, primary_key = True)
    pp = db.Column(db.String, nullable = False)
    region = db.Column(db.String, nullable = False)
    name = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    tel = db.Column(db.String, nullable = False)
    
    def __init__(self, num, pp, region, name, addr, tel):
        self.num = num
        self.pp = pp
        self.region = region
        self.name = name
        self.addr = addr
        self.tel = tel
        
class es(db.Model): #國小
    __tablename__ = "elementary_school"
    num = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String, nullable = False)
    region = db.Column(db.String, nullable = False)
    region1 = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    tel = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, region, region1, addr, tel):
        self.num = num
        self.name = name
        self.region = region
        self.region1 = region1
        self.addr = addr
        self.tel = tel
        
class jh(db.Model): #國中
    __tablename__ = "junior_high"
    num = db.Column(db.Integer, primary_key = True)
    region = db.Column(db.String, nullable = False)
    name = db.Column(db.String, nullable = False)
    id = db.Column(db.String, nullable = False)
    region1 = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    tel = db.Column(db.String, nullable = False)
    
    def __init__(self, num, region, name, id, region1, addr, tel):
        self.num = num
        self.region = region
        self.name = name
        self.id = id
        self.region1 = region1
        self.addr = addr
        self.tel = tel
        
class hp(db.Model): #房價
    __tablename__ = "house_price"
    num = db.Column(db.Integer, primary_key = True)
    region = db.Column(db.String, nullable = False)
    price = db.Column(db.String, nullable = False)
    
    def __init__(self, num, region, price):
        self.num = num
        self.region = region
        self.price = price
    
class po(db.Model): #警察局
    __tablename__ = "police_station"
    num = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String, nullable = False)
    content = db.Column(db.String, nullable = False)
    display_addr = db.Column(db.String, nullable = False)
    poi_addr = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, content, display_addr, poi_addr):
        self.num = num
        self.name = name
        self.content = content
        self.display_addr = display_addr
        self.poi_addr = poi_addr
        
class ho(db.Model): #醫院
    __tablename__ = "hospital"
    num = db.Column(db.String, primary_key = True)
    name = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, addr):
        self.num = num
        self.name = name
        self.addr = addr
        
class cl(db.Model): #診所
    __tablename__ = "clinic"
    num = db.Column(db.String, primary_key = True)
    name = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, addr):
        self.num = num
        self.name = name
        self.addr = addr
        
class mrt(db.Model): #MRT
    __tablename__ = "mrt"
    num = db.Column(db.String, primary_key = True)
    id = db.Column(db.String, nullable = False)
    station = db.Column(db.String, nullable = False)
    region = db.Column(db.String, nullable = False)
    
    def __init__(self, num, id, station, region):
        self.num = num
        self.id = id
        self.station = station
        self.region = region
        
class ds(db.Model): #百貨公司
    __tablename__ = "department_store"
    num = db.Column(db.String, primary_key = True)
    name = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, addr):
        self.num = num
        self.name = name
        self.addr = addr
     
class pk(db.Model): #公園
    __tablename__ = "park"
    num = db.Column(db.String, primary_key = True)
    region = db.Column(db.String, nullable = False)
    name = db.Column(db.String, nullable = False)
    
    def __init__(self, num, region, name):
        self.num = num
        self.region = region
        self.name = name
        
class mv(db.Model): #電影院
    __tablename__ = "movie"
    num = db.Column(db.String, primary_key = True)
    name = db.Column(db.String, nullable = False)
    addr = db.Column(db.String, nullable = False)
    
    def __init__(self, num, name, addr):
        self.num = num
        self.name = name
        self.addr = addr