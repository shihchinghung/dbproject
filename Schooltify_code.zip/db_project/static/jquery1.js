window.onload = function(){hide_all(); };

function child1()
{
    var obj = document.getElementById('child1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function child2()
{
    var obj = document.getElementById('child2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function child3()
{
    var obj = document.getElementById('child3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function hide_all()
{
    document.getElementById('child1').style.display = 'none';
    document.getElementById('child2').style.display = 'none';
    document.getElementById('child3').style.display = 'none';
}

function changeColor1(){
    document.getElementById("wh").style.background='#B09FDC';
}
function changeColor2(){
    document.getElementById("cj").style.background='#B09FDC';
}
function changeColor3(){
    document.getElementById("ta").style.background='#B09FDC';
}
function changeColor4(){
    document.getElementById("xi").style.background='#B09FDC';
}
function changeColor5(){
    document.getElementById("ng").style.background='#B09FDC';
}
function changeColor6(){
    document.getElementById("ws").style.background='#B09FDC';
}
function changeColor7(){
    document.getElementById("dt").style.background='#B09FDC';
}
function changeColor8(){
    document.getElementById("cs").style.background='#B09FDC';
}
function changeColor9(){
    document.getElementById("ss").style.background='#B09FDC';
}
function changeColor10(){
    document.getElementById("nh").style.background='#B09FDC';
}
function changeColor11(){
    document.getElementById("bt").style.background='#B09FDC';
}
function changeColor12(){
    document.getElementById("sl").style.background='#B09FDC';
}


function baby(){
    document.getElementById("baby").style.background='#B09FDC';
}
function child(){
    document.getElementById("child").style.background='#B09FDC';
}
function adolo(){
    document.getElementById("adolo").style.background='#B09FDC';
}


function b1(){
    document.getElementById("b1").style.background='#B09FDC';
}
function b2(){
    document.getElementById("b2").style.background='#B09FDC';
}
function b3(){
    document.getElementById("b3").style.background='#B09FDC';
}
function b4(){
    document.getElementById("b4").style.background='#B09FDC';
}
function b5(){
    document.getElementById("b5").style.background='#B09FDC';
}
function b6(){
    document.getElementById("b6").style.background='#B09FDC';
}
function b7(){
    document.getElementById("b7").style.background='#B09FDC';
}
function b8(){
    document.getElementById("b8").style.background='#B09FDC';
}
function b9(){
    document.getElementById("b9").style.background='#B09FDC';
}




function c1(){
    document.getElementById("c1").style.background='#B09FDC';
}
function c2(){
    document.getElementById("c2").style.background='#B09FDC';
}
function c3(){
    document.getElementById("c3").style.background='#B09FDC';
}
function c4(){
    document.getElementById("c4").style.background='#B09FDC';
}
function c5(){
    document.getElementById("c5").style.background='#B09FDC';
}
function c6(){
    document.getElementById("c6").style.background='#B09FDC';
}
function c7(){
    document.getElementById("c7").style.background='#B09FDC';
}
function c8(){
    document.getElementById("c8").style.background='#B09FDC';
}
function c9(){
    document.getElementById("c9").style.background='#B09FDC';
}


function a1(){
    document.getElementById("a1").style.background='#B09FDC';
}
function a2(){
    document.getElementById("a2").style.background='#B09FDC';
}
function a3(){
    document.getElementById("a3").style.background='#B09FDC';
}
function a4(){
    document.getElementById("a4").style.background='#B09FDC';
}
function a5(){
    document.getElementById("a5").style.background='#B09FDC';
}
function a6(){
    document.getElementById("a6").style.background='#B09FDC';
}
function a7(){
    document.getElementById("a7").style.background='#B09FDC';
}
function a8(){
    document.getElementById("a8").style.background='#B09FDC';
}
function a9(){
    document.getElementById("a9").style.background='#B09FDC';
}

function a(){
    document.getElementById("a").style.background='#B09FDC';
}

function b(){
    document.getElementById("b").style.background='#B09FDC';
}

function e(){
    document.getElementById("e").style.background='#B09FDC';
}

function s(){
    document.getElementById("s").style.background='#B09FDC';
}

function h(){
    document.getElementById("h").style.background='#B09FDC';
}

function l(){
    document.getElementById("l").style.background='#B09FDC';
}
