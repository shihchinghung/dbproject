from flask import Flask #網站後端
from flask import render_template
from flask import request
from flask_sqlalchemy import SQLAlchemy
from table import hp, ps, po, es, jh, ho, cl, mrt, ds, pk, mv

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://hungshihching:poesypoesy@127.0.0.1:5432/hungshihching'
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://wleyigkpxxlcaw:3b9e74fb37328cc1b8424159344136d134d1e77f98c28c27d5ea20a1976e24be@ec2-54-157-16-196.compute-1.amazonaws.com:5432/d35acaesipkqk3'

db = SQLAlchemy() #連接資料庫
db.init_app(app)

@app.route('/home_page.html', methods=['POST', 'GET'])
def home_page():
    if request.method == 'POST':
        hinput = request.form.get('a') #input region
        psall = ps.query.all() #preschool
        esall = es.query.all() #elementtary school
        jhall = jh.query.all() #junior high
        hpall = hp.query.all() #house price
        poall = po.query.all() #police station
        hoall = ho.query.all() #hospital
        clall = cl.query.all() #clinic
        mrtall = mrt.query.all() #mrt
        dsall = ds.query.all() #department store
        pkall = pk.query.all() #park
        mvall = mv.query.all() #movie
        result = ['result: ']
        n=0
        for i in hpall: #判斷輸入是否為地區
            i1 = str(i.region)
            if hinput in i1:
                result.append('- 平均房價: ')
                result.append(i.price)
                n=1
        result.append('-   幼兒園')
        result.append(' ')
        for i in psall:
            i1 = str(i.region)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 國小')
        result.append(' ')
        for i in esall:
            i1 = str(i.region1)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 國中')
        result.append(' ')
        for i in jhall:
            i1 = str(i.region1)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 警察局')
        result.append(' ')
        for i in poall:
            i1 = str(i.poi_addr)
            if hinput in i1:
                result.append(i.name)
                result.append(i.poi_addr)
        result.append('- 公園')
        result.append(' ')
        for i in pkall:
            i1 = str(i.region)
            if hinput in i1:
                result.append(i.name)
                result.append(' ')
        result.append('- 捷運站')
        result.append(' ')
        for i in mrtall:
            i1 = str(i.region)
            if hinput in i1:
                result.append(i.station)
                result.append(' ')
        result.append('- 電影院')
        result.append(' ')
        for i in mvall:
            i1 = str(i.addr)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 醫院')
        result.append(' ')
        for i in hoall:
            i1 = str(i.addr)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 診所')
        result.append(' ')
        for i in clall:
            i1 = str(i.addr)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        result.append('- 百貨公司')
        result.append(' ')
        for i in dsall:
            i1 = str(i.addr)
            if hinput in i1:
                result.append(i.name)
                result.append(i.addr)
        if n == 0:
            result.append('請輸入地區搜尋')            
        print(hinput)
        print(result)
        return render_template("home_page.html", result=result)
    return render_template('home_page.html')

@app.route('/home_result.html')
def home_result():
    return render_template('home_result.html')

@app.route('/recommend.html')
def recommend():
    return render_template('recommend.html')

@app.route('/recom_result.html')
def recom_result():
    return render_template('recom_result.html')

@app.route('/about.html')
def about():
    return render_template('about.html')

@app.route('/select.html', methods=['POST', 'GET'])
def select():
    if request.method == 'POST':
        #if request.values['submit'] == 'submit':
        hregion = request.form.getlist('a') #region
        hschool = request.form.getlist('b') #age
        hlife = request.form.getlist('c') #life
        psall = ps.query.all() #police station
        esall = es.query.all() #elementtary school
        jhall = jh.query.all() #junior high
        hpall = hp.query.all() #house price
        poall = po.query.all() #preschool
        hoall = ho.query.all() #hospital
        clall = cl.query.all() #clinic
        mrtall = mrt.query.all() #mrt
        dsall = ds.query.all() #department store
        pkall = pk.query.all() #park
        mvall = mv.query.all() #movie
        result = ['result: ']
        #result = '\n'
        for i in hregion: #從地區開始搜尋
            for j in hpall:
                i1 = str(j.region)
                if i == i1:
                    result.append(j.region)
                    result.append(':')
                    for k in hschool:
                        if k == '幼兒園':
                            result.append('-   幼兒園')
                            result.append(' ')
                            for l in psall:
                                i2 = str(l.region)
                                if i == i2:
                                    result.append(l.name)
                                    result.append(l.addr)
                        if k == '國小':
                            result.append('- 國小')
                            result.append(' ')
                            for l in esall:
                                i2 = str(l.region1)
                                if i == i2:
                                    result.append(l.name)
                                    result.append(l.addr)
                        if k == '國中':
                            result.append('- 國中')
                            result.append(' ')
                            for l in jhall:
                                i2 = str(l.region1)
                                if i == i2:
                                    result.append(l.name)
                                    result.append(l.addr)
                        #result += '\n'
                    for k in hlife:
                        if k == '平均房價':
                            result.append('- 平均房價: ')
                            result.append(' ')
                            for l in hpall:
                                i3 = str(l.region)
                                if i == i3:
                                    result.append(l.price)
                                    result.append(' ')
                        if k == '生活機能':
                            result.append('- 生活機能')
                            result.append(' ')
                            print('\n')
                            result.append('- 警察局')
                            result.append(' ')
                            for l in poall:
                                i3 = str(l.poi_addr)
                                if i in i3:
                                    result.append(l.name)
                                    result.append(l.poi_addr)
                            result.append('- 醫院')
                            result.append(' ')        
                            for l in hoall:
                                i3 = str(l.addr)
                                if i in i3:
                                    result.append(l.name)
                                    result.append(l.addr)
                            result.append('- 診所')
                            result.append(' ')
                            for l in clall:
                                i3 = str(l.addr)
                                if i in i3:
                                    result.append(l.name)
                                    result.append(l.addr)
                            result.append('- 捷運站')
                            result.append(' ')
                            for l in mrtall:
                                i3 = str(l.region)
                                if i == i3:
                                    result.append(l.station)
                                    result.append(' ')
                            result.append('- 百貨公司')
                            result.append(' ')
                            for l in dsall:
                                i3 = str(l.addr)
                                if i in i3:
                                    result.append(l.name)
                                    result.append(l.addr)
                            result.append('- 公園')
                            result.append(' ')
                            for l in pkall:
                                i3 = str(l.region)
                                if i == i3:
                                    result.append(l.name)
                                    result.append(' ')
                            result.append('- 電影院')
                            result.append(' ')
                            for l in mvall:
                                print(l.name)
                                i3 = str(l.addr)
                                if i in i3:
                                    result.append(l.name)
                                    result.append(l.addr)
        print(result)
        print(request.form.getlist('a'))
        print(request.form.getlist('b'))
        print(request.form.getlist('c'))
        return render_template("select.html", result=result)
    return render_template("select.html")

@app.route('/')
def index():
    db.create_all()
    return '資料庫連線成功'


if __name__ == '__main__':
    app.run()